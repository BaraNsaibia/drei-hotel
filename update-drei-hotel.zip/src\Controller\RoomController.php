<?php

namespace App\Controller;

use App\Entity\Room;
use App\Form\ReservationType;
use App\Repository\RoomRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RoomController extends AbstractController
{
    #[Route('/chambres', name: 'app_rooms')]
    public function index(Request $request, RoomRepository $roomRepository): Response
    {
        $type = $request->query->get('type');
        $capacity = $request->query->getInt('capacity') ?: null;
        $maxPrice = $request->query->get('max_price') ? (float) $request->query->get('max_price') : null;
        $checkInStr = $request->query->get('check_in');
        $checkOutStr = $request->query->get('check_out');

        $checkIn = null;
        $checkOut = null;

        if (!empty($checkInStr) && !empty($checkOutStr)) {
            try {
                $checkIn = new \DateTime($checkInStr);
                $checkOut = new \DateTime($checkOutStr);
            } catch (\Exception) {
                // Ignore invalid date format
            }
        }

        // If dates are provided, search available rooms for that date range
        if ($checkIn && $checkOut && $checkOut > $checkIn) {
            $rooms = $roomRepository->findAvailableRoomsForDates($checkIn, $checkOut, $capacity, $type, $maxPrice);
        } else {
            // Otherwise search with standard filters
            $rooms = $roomRepository->findWithFilters($type, $capacity, $maxPrice);
        }

        return $this->render('room/index.html.twig', [
            'rooms' => $rooms,
            'selected_type' => $type,
            'selected_capacity' => $capacity,
            'selected_max_price' => $maxPrice,
            'selected_check_in' => $checkInStr,
            'selected_check_out' => $checkOutStr,
        ]);
    }

    #[Route('/chambres/{id}', name: 'app_room_show', requirements: ['id' => '\d+'])]
    public function show(Room $room): Response
    {
        // Reservation form for direct booking initiation
        $form = $this->createForm(ReservationType::class);

        return $this->render('room/show.html.twig', [
            'room' => $room,
            'form' => $form->createView(),
        ]);
    }
}
