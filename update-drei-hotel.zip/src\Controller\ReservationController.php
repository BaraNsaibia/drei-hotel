<?php

namespace App\Controller;

use App\Entity\Reservation;
use App\Entity\Room;
use App\Entity\User;
use App\Form\ReservationType;
use App\Repository\ReservationRepository;
use App\Service\ReservationManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

class ReservationController extends AbstractController
{
    #[Route('/reserver/{id}', name: 'app_reservation_new', requirements: ['id' => '\d+'])]
    #[IsGranted('ROLE_USER')]
    public function new(
        Room $room,
        Request $request,
        ReservationManager $reservationManager
    ): Response {
        /** @var User $user */
        $user = $this->getUser();

        // Check if room is active
        if (!$room->isAvailable()) {
            $this->addFlash('danger', 'Cette chambre n\'est pas disponible à la réservation.');
            return $this->redirectToRoute('app_rooms');
        }

        $reservation = new Reservation();
        $reservation->setRoom($room);
        $reservation->setUser($user);

        // Pre-fill dates from query parameters if available
        if ($request->query->get('check_in')) {
            try {
                $reservation->setCheckIn(new \DateTime($request->query->get('check_in')));
            } catch (\Exception) {}
        }
        if ($request->query->get('check_out')) {
            try {
                $reservation->setCheckOut(new \DateTime($request->query->get('check_out')));
            } catch (\Exception) {}
        }
        if ($request->query->getInt('guests')) {
            $reservation->setGuests(min($room->getCapacity(), $request->query->getInt('guests')));
        }

        $form = $this->createForm(ReservationType::class, $reservation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $checkIn = $reservation->getCheckIn();
            $checkOut = $reservation->getCheckOut();

            // 1. Validation: checkIn cannot be in the past (before today)
            $today = new \DateTime('today');
            if ($checkIn < $today) {
                $this->addFlash('danger', 'La date d\'arrivée ne peut pas être située dans le passé.');
                return $this->render('reservation/new.html.twig', [
                    'room' => $room,
                    'form' => $form->createView(),
                ]);
            }

            // 2. Validation: checkOut must be strictly after checkIn
            if ($checkOut <= $checkIn) {
                $this->addFlash('danger', 'La date de départ doit être postérieure à la date d\'arrivée.');
                return $this->render('reservation/new.html.twig', [
                    'room' => $room,
                    'form' => $form->createView(),
                ]);
            }

            // 3. Validation: check capacity
            if ($reservation->getGuests() > $room->getCapacity()) {
                $this->addFlash('danger', sprintf('Cette chambre peut accueillir au maximum %d personne(s).', $room->getCapacity()));
                return $this->render('reservation/new.html.twig', [
                    'room' => $room,
                    'form' => $form->createView(),
                ]);
            }

            // 4. Availability Check: ensure no overlapping reservations
            if (!$reservationManager->isRoomAvailable($room, $checkIn, $checkOut)) {
                $this->addFlash('danger', 'Cette chambre n\'est pas disponible pour les dates sélectionnées. Veuillez choisir d\'autres dates.');
                return $this->render('reservation/new.html.twig', [
                    'room' => $room,
                    'form' => $form->createView(),
                ]);
            }

            // 5. Create reservation via manager service
            try {
                $createdReservation = $reservationManager->createReservation(
                    $user,
                    $room,
                    $checkIn,
                    $checkOut,
                    $reservation->getGuests(),
                    $reservation->getNotes()
                );

                $this->addFlash('success', 'Votre réservation a été enregistrée avec succès.');

                return $this->redirectToRoute('app_reservation_confirmation', [
                    'reference' => $createdReservation->getReference(),
                ]);
            } catch (\Exception $e) {
                $this->addFlash('danger', 'Une erreur est survenue lors de l\'enregistrement : ' . $e->getMessage());
            }
        }

        return $this->render('reservation/new.html.twig', [
            'room' => $room,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/reservation/confirmation/{reference}', name: 'app_reservation_confirmation')]
    #[IsGranted('ROLE_USER')]
    public function confirmation(
        string $reference,
        ReservationRepository $reservationRepository
    ): Response {
        /** @var User $user */
        $user = $this->getUser();

        $reservation = $reservationRepository->findOneBy(['reference' => $reference]);

        if (!$reservation) {
            throw $this->createNotFoundException('Réservation introuvable.');
        }

        // Only the customer who booked or an admin can see the confirmation
        if ($reservation->getUser() !== $user && !$this->isGranted('ROLE_ADMIN')) {
            throw $this->createAccessDeniedException('Accès non autorisé.');
        }

        return $this->render('reservation/confirmation.html.twig', [
            'reservation' => $reservation,
        ]);
    }
}
