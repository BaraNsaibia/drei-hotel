<?php

namespace App\Controller\Admin;

use App\Entity\Reservation;
use App\Entity\Room;
use App\Repository\ReservationRepository;
use App\Repository\RoomRepository;
use App\Repository\UserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/admin')]
#[IsGranted('ROLE_ADMIN')]
class AdminDashboardController extends AbstractController
{
    #[Route('', name: 'app_admin_dashboard')]
    public function index(
        RoomRepository $roomRepository,
        ReservationRepository $reservationRepository,
        UserRepository $userRepository
    ): Response {
        $totalRooms = $roomRepository->count([]);
        $totalReservations = $reservationRepository->count([]);
        $pendingReservations = $reservationRepository->countByStatus(Reservation::STATUS_PENDING);
        $confirmedReservations = $reservationRepository->countByStatus(Reservation::STATUS_CONFIRMED);
        $totalRevenue = $reservationRepository->calculateTotalRevenue();
        $totalCustomers = $userRepository->countCustomers();
        $latestReservations = $reservationRepository->findLatest(5);

        return $this->render('admin/dashboard/index.html.twig', [
            'total_rooms' => $totalRooms,
            'total_reservations' => $totalReservations,
            'pending_reservations' => $pendingReservations,
            'confirmed_reservations' => $confirmedReservations,
            'total_revenue' => $totalRevenue,
            'total_customers' => $totalCustomers,
            'latest_reservations' => $latestReservations,
        ]);
    }
}
