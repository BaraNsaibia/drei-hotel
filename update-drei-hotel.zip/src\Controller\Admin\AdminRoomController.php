<?php

namespace App\Controller\Admin;

use App\Entity\Room;
use App\Form\RoomType;
use App\Repository\RoomRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/admin/chambres')]
#[IsGranted('ROLE_ADMIN')]
class AdminRoomController extends AbstractController
{
    #[Route('', name: 'app_admin_rooms')]
    public function index(RoomRepository $roomRepository): Response
    {
        $rooms = $roomRepository->findBy([], ['id' => 'DESC']);

        return $this->render('admin/room/index.html.twig', [
            'rooms' => $rooms,
        ]);
    }

    #[Route('/ajouter', name: 'app_admin_room_new')]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $room = new Room();
        $form = $this->createForm(RoomType::class, $room);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $room->setCreatedAt(new \DateTimeImmutable());
            $entityManager->persist($room);
            $entityManager->flush();

            $this->addFlash('success', 'La chambre a été ajoutée avec succès.');

            return $this->redirectToRoute('app_admin_rooms');
        }

        return $this->render('admin/room/new.html.twig', [
            'room' => $room,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}/modifier', name: 'app_admin_room_edit')]
    public function edit(Room $room, Request $request, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(RoomType::class, $room);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $room->setUpdatedAt(new \DateTimeImmutable());
            $entityManager->flush();

            $this->addFlash('success', 'La chambre a été modifiée avec succès.');

            return $this->redirectToRoute('app_admin_rooms');
        }

        return $this->render('admin/room/edit.html.twig', [
            'room' => $room,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}/statut', name: 'app_admin_room_toggle_status', methods: ['POST'])]
    public function toggleStatus(Room $room, Request $request, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('toggle_status_' . $room->getId(), $request->request->get('_token'))) {
            $newStatus = $room->isAvailable() ? Room::STATUS_UNAVAILABLE : Room::STATUS_AVAILABLE;
            $room->setStatus($newStatus);
            $room->setUpdatedAt(new \DateTimeImmutable());
            $entityManager->flush();

            $this->addFlash('success', 'Le statut de la chambre a été mis à jour.');
        }

        return $this->redirectToRoute('app_admin_rooms');
    }

    #[Route('/{id}/supprimer', name: 'app_admin_room_delete', methods: ['POST'])]
    public function delete(Room $room, Request $request, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete_room_' . $room->getId(), $request->request->get('_token'))) {
            $entityManager->remove($room);
            $entityManager->flush();

            $this->addFlash('success', 'La chambre a été supprimée avec succès.');
        }

        return $this->redirectToRoute('app_admin_rooms');
    }
}
