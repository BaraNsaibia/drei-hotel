<?php

namespace App\Repository;

use App\Entity\Reservation;
use App\Entity\Room;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Room>
 */
class RoomRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Room::class);
    }

    /**
     * Find featured rooms for the home page.
     *
     * @return Room[]
     */
    public function findFeaturedRooms(int $limit = 3): array
    {
        return $this->createQueryBuilder('r')
            ->where('r.status = :status')
            ->setParameter('status', Room::STATUS_AVAILABLE)
            ->orderBy('r.pricePerNight', 'ASC')
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }

    /**
     * Search and filter rooms by type, capacity, and max price.
     *
     * @return Room[]
     */
    public function findWithFilters(?string $type = null, ?int $capacity = null, ?float $maxPrice = null): array
    {
        $qb = $this->createQueryBuilder('r')
            ->where('r.status = :status')
            ->setParameter('status', Room::STATUS_AVAILABLE);

        if (!empty($type)) {
            $qb->andWhere('r.type = :type')
               ->setParameter('type', $type);
        }

        if (!empty($capacity)) {
            $qb->andWhere('r.capacity >= :capacity')
               ->setParameter('capacity', $capacity);
        }

        if (!empty($maxPrice)) {
            $qb->andWhere('r.pricePerNight <= :maxPrice')
               ->setParameter('maxPrice', $maxPrice);
        }

        return $qb->orderBy('r.pricePerNight', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * Find all rooms available for a specific date range.
     *
     * @return Room[]
     */
    public function findAvailableRoomsForDates(
        \DateTimeInterface $checkIn,
        \DateTimeInterface $checkOut,
        ?int $capacity = null,
        ?string $type = null,
        ?float $maxPrice = null
    ): array {
        // Find room IDs that currently have conflicting reservations
        $overlappingQb = $this->getEntityManager()->createQueryBuilder();
        $overlappingResults = $overlappingQb->select('DISTINCT IDENTITY(res.room) AS roomId')
            ->from(Reservation::class, 'res')
            ->where('res.status != :cancelled')
            ->andWhere('res.checkIn < :checkOut')
            ->andWhere('res.checkOut > :checkIn')
            ->setParameter('cancelled', Reservation::STATUS_CANCELLED)
            ->setParameter('checkIn', $checkIn)
            ->setParameter('checkOut', $checkOut)
            ->getQuery()
            ->getScalarResult();

        $unavailableRoomIds = array_column($overlappingResults, 'roomId');

        $qb = $this->createQueryBuilder('r')
            ->where('r.status = :available')
            ->setParameter('available', Room::STATUS_AVAILABLE);

        if (!empty($unavailableRoomIds)) {
            $qb->andWhere('r.id NOT IN (:unavailableIds)')
               ->setParameter('unavailableIds', $unavailableRoomIds);
        }

        if (!empty($capacity)) {
            $qb->andWhere('r.capacity >= :capacity')
               ->setParameter('capacity', $capacity);
        }

        if (!empty($type)) {
            $qb->andWhere('r.type = :type')
               ->setParameter('type', $type);
        }

        if (!empty($maxPrice)) {
            $qb->andWhere('r.pricePerNight <= :maxPrice')
               ->setParameter('maxPrice', $maxPrice);
        }

        return $qb->orderBy('r.pricePerNight', 'ASC')
            ->getQuery()
            ->getResult();
    }
}
