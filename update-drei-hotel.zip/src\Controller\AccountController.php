<?php

namespace App\Controller;

use App\Entity\Reservation;
use App\Entity\User;
use App\Repository\ReservationRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('ROLE_USER')]
class AccountController extends AbstractController
{
    #[Route('/mon-compte', name: 'app_account')]
    public function index(ReservationRepository $reservationRepository): Response
    {
        /** @var User $user */
        $user = $this->getUser();

        // Find user reservations ordered by date
        $reservations = $reservationRepository->findBy(
            ['user' => $user],
            ['createdAt' => 'DESC']
        );

        return $this->render('account/index.html.twig', [
            'user' => $user,
            'reservations' => $reservations,
        ]);
    }

    #[Route('/mon-compte/reservation/{id}/annuler', name: 'app_account_cancel_reservation', methods: ['POST'])]
    public function cancelReservation(
        Reservation $reservation,
        Request $request,
        EntityManagerInterface $entityManager
    ): Response {
        /** @var User $user */
        $user = $this->getUser();

        if ($reservation->getUser() !== $user) {
            throw $this->createAccessDeniedException('Accès refusé.');
        }

        if (!$this->isCsrfTokenValid('cancel_res_' . $reservation->getId(), $request->request->get('_token'))) {
            $this->addFlash('danger', 'Jeton de sécurité CSRF invalide.');
            return $this->redirectToRoute('app_account');
        }

        // Only pending or confirmed reservations can be cancelled
        if (in_array($reservation->getStatus(), [Reservation::STATUS_PENDING, Reservation::STATUS_CONFIRMED], true)) {
            $reservation->setStatus(Reservation::STATUS_CANCELLED);
            $entityManager->flush();
            $this->addFlash('success', 'Votre réservation a été annulée avec succès.');
        } else {
            $this->addFlash('warning', 'Cette réservation ne peut plus être annulée.');
        }

        return $this->redirectToRoute('app_account');
    }
}
