<?php

namespace App\Controller;

use App\Repository\RoomRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home')]
    public function index(RoomRepository $roomRepository): Response
    {
        // Get 3 featured available rooms for home page
        $featuredRooms = $roomRepository->findFeaturedRooms(3);

        return $this->render('home/index.html.twig', [
            'featured_rooms' => $featuredRooms,
        ]);
    }

    #[Route('/a-propos', name: 'app_about')]
    public function about(): Response
    {
        return $this->render('home/about.html.twig');
    }

    #[Route('/services', name: 'app_services')]
    public function services(): Response
    {
        return $this->render('home/services.html.twig');
    }

    #[Route('/contact', name: 'app_contact')]
    public function contact(Request $request): Response
    {
        $submitted = false;
        if ($request->isMethod('POST')) {
            $this->addFlash('success', 'Votre message a été envoyé avec succès. Notre équipe vous répondra dans les plus brefs délais.');
            $submitted = true;
        }

        return $this->render('home/contact.html.twig', [
            'submitted' => $submitted,
        ]);
    }
}
