<?php

namespace App\Form;

use App\Entity\Room;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\CallbackTransformer;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RoomType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('name', TextType::class, [
                'label' => 'Nom de la chambre',
                'attr' => [
                    'placeholder' => 'Ex: Chambre Deluxe avec Vue Mer',
                    'class' => 'form-control',
                ],
            ])
            ->add('type', ChoiceType::class, [
                'label' => 'Type de chambre',
                'choices' => [
                    'Chambre Standard' => Room::TYPE_STANDARD,
                    'Chambre Deluxe' => Room::TYPE_DELUXE,
                    'Suite Drei' => Room::TYPE_SUITE,
                    'Chambre Familiale' => Room::TYPE_FAMILY,
                ],
                'attr' => ['class' => 'form-select'],
            ])
            ->add('pricePerNight', NumberType::class, [
                'label' => 'Prix par nuit (€)',
                'scale' => 2,
                'attr' => [
                    'placeholder' => '120.00',
                    'class' => 'form-control',
                    'step' => '0.50',
                ],
            ])
            ->add('capacity', IntegerType::class, [
                'label' => 'Capacité (personnes)',
                'attr' => [
                    'min' => 1,
                    'max' => 10,
                    'class' => 'form-control',
                ],
            ])
            ->add('surface', IntegerType::class, [
                'label' => 'Superficie (m²)',
                'required' => false,
                'attr' => [
                    'placeholder' => 'Ex: 35',
                    'class' => 'form-control',
                ],
            ])
            ->add('bedType', TextType::class, [
                'label' => 'Type de lit',
                'required' => false,
                'attr' => [
                    'placeholder' => 'Ex: 1 grand lit King Size',
                    'class' => 'form-control',
                ],
            ])
            ->add('status', ChoiceType::class, [
                'label' => 'Statut de disponibilité',
                'choices' => [
                    'Disponible' => Room::STATUS_AVAILABLE,
                    'Indisponible' => Room::STATUS_UNAVAILABLE,
                ],
                'attr' => ['class' => 'form-select'],
            ])
            ->add('image', TextType::class, [
                'label' => 'Nom ou URL de l\'image',
                'required' => false,
                'attr' => [
                    'placeholder' => 'deluxe-room.jpg ou URL externe',
                    'class' => 'form-control',
                ],
                'help' => 'Fichier situé dans public/images/rooms/ ou lien image externe',
            ])
            ->add('amenities', TextType::class, [
                'label' => 'Équipements (séparés par des virgules)',
                'required' => false,
                'attr' => [
                    'placeholder' => 'Wi-Fi gratuit, Climatisation, Vue mer, Mini-bar, Coffre-fort',
                    'class' => 'form-control',
                ],
                'help' => 'Exemple: Wi-Fi gratuit, Climatisation, Petit-déjeuner inclus',
            ])
            ->add('description', TextareaType::class, [
                'label' => 'Description détaillée',
                'attr' => [
                    'rows' => 5,
                    'placeholder' => 'Présentation complète de la chambre, du confort et des avantages...',
                    'class' => 'form-control',
                ],
            ]);

        // Transform array of amenities to comma-separated string and vice versa
        $builder->get('amenities')
            ->addModelTransformer(new CallbackTransformer(
                function ($amenitiesAsArray) {
                    if (is_array($amenitiesAsArray)) {
                        return implode(', ', $amenitiesAsArray);
                    }
                    return (string) $amenitiesAsArray;
                },
                function ($amenitiesAsString) {
                    if (empty($amenitiesAsString)) {
                        return [];
                    }
                    return array_map('trim', explode(',', (string) $amenitiesAsString));
                }
            ));
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Room::class,
        ]);
    }
}
