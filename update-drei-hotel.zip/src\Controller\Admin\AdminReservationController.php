<?php

namespace App\Controller\Admin;

use App\Entity\Reservation;
use App\Repository\ReservationRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/admin/reservations')]
#[IsGranted('ROLE_ADMIN')]
class AdminReservationController extends AbstractController
{
    #[Route('', name: 'app_admin_reservations')]
    public function index(Request $request, ReservationRepository $reservationRepository): Response
    {
        $status = $request->query->get('status');

        $criteria = [];
        if (!empty($status)) {
            $criteria['status'] = $status;
        }

        $reservations = $reservationRepository->findBy($criteria, ['createdAt' => 'DESC']);

        return $this->render('admin/reservation/index.html.twig', [
            'reservations' => $reservations,
            'current_status' => $status,
        ]);
    }

    #[Route('/{id}', name: 'app_admin_reservation_show', requirements: ['id' => '\d+'])]
    public function show(Reservation $reservation): Response
    {
        return $this->render('admin/reservation/show.html.twig', [
            'reservation' => $reservation,
        ]);
    }

    #[Route('/{id}/statut', name: 'app_admin_reservation_update_status', methods: ['POST'])]
    public function updateStatus(
        Reservation $reservation,
        Request $request,
        EntityManagerInterface $entityManager
    ): Response {
        if ($this->isCsrfTokenValid('status_' . $reservation->getId(), $request->request->get('_token'))) {
            $newStatus = $request->request->get('status');
            $allowedStatuses = [
                Reservation::STATUS_PENDING,
                Reservation::STATUS_CONFIRMED,
                Reservation::STATUS_CANCELLED,
                Reservation::STATUS_COMPLETED,
            ];

            if (in_array($newStatus, $allowedStatuses, true)) {
                $reservation->setStatus($newStatus);
                $entityManager->flush();
                $this->addFlash('success', sprintf('Le statut de la réservation a été changé en "%s".', $reservation->getStatusLabel()));
            }
        }

        return $this->redirectToRoute('app_admin_reservation_show', ['id' => $reservation->getId()]);
    }

    #[Route('/{id}/paiement', name: 'app_admin_reservation_update_payment', methods: ['POST'])]
    public function updatePayment(
        Reservation $reservation,
        Request $request,
        EntityManagerInterface $entityManager
    ): Response {
        if ($this->isCsrfTokenValid('payment_' . $reservation->getId(), $request->request->get('_token'))) {
            $newPayment = $request->request->get('payment_status');
            $allowedPayments = [
                Reservation::PAYMENT_ON_SITE,
                Reservation::PAYMENT_PAID,
            ];

            if (in_array($newPayment, $allowedPayments, true)) {
                $reservation->setPaymentStatus($newPayment);
                // If marked paid, we can automatically confirm if still pending
                if ($newPayment === Reservation::PAYMENT_PAID && $reservation->getStatus() === Reservation::STATUS_PENDING) {
                    $reservation->setStatus(Reservation::STATUS_CONFIRMED);
                }
                $entityManager->flush();
                $this->addFlash('success', sprintf('Le statut de paiement a été mis à jour : "%s".', $reservation->getPaymentStatusLabel()));
            }
        }

        return $this->redirectToRoute('app_admin_reservation_show', ['id' => $reservation->getId()]);
    }
}
