<?php

namespace App\Service;

use App\Entity\Reservation;
use App\Entity\Room;
use App\Entity\User;
use App\Repository\ReservationRepository;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Service to handle hotel reservation logic:
 * - Availability verification (double-booking prevention)
 * - Calculation of nights and total price
 * - Reservation creation and management
 */
class ReservationManager
{
    public function __construct(
        private readonly ReservationRepository $reservationRepository,
        private readonly EntityManagerInterface $entityManager
    ) {
    }

    /**
     * Calculate the number of nights between check-in and check-out.
     */
    public function calculateNights(\DateTimeInterface $checkIn, \DateTimeInterface $checkOut): int
    {
        $days = (int) $checkIn->diff($checkOut)->days;

        return max(1, $days);
    }

    /**
     * Calculate the total price for a stay.
     * Formula: Number of nights * Price per night
     */
    public function calculateTotal(
        float $pricePerNight,
        \DateTimeInterface $checkIn,
        \DateTimeInterface $checkOut
    ): float {
        $nights = $this->calculateNights($checkIn, $checkOut);

        return round($pricePerNight * $nights, 2);
    }

    /**
     * Check if a room is available for the specified date range.
     * Returns true if available, false if there is an overlapping reservation.
     */
    public function isRoomAvailable(
        Room $room,
        \DateTimeInterface $checkIn,
        \DateTimeInterface $checkOut,
        ?int $excludeReservationId = null
    ): bool {
        // A room marked unavailable by admin cannot be booked
        if (!$room->isAvailable()) {
            return false;
        }

        // Check if there are any conflicting reservations
        $overlapping = $this->reservationRepository->findOverlappingReservations(
            $room,
            $checkIn,
            $checkOut,
            $excludeReservationId
        );

        return count($overlapping) === 0;
    }

    /**
     * Create and persist a new reservation.
     */
    public function createReservation(
        User $user,
        Room $room,
        \DateTimeInterface $checkIn,
        \DateTimeInterface $checkOut,
        int $guests,
        ?string $notes = null
    ): Reservation {
        // 1. Double check availability
        if (!$this->isRoomAvailable($room, $checkIn, $checkOut)) {
            throw new \InvalidArgumentException('Cette chambre n\'est pas disponible pour les dates sélectionnées.');
        }

        // 2. Calculate total
        $totalPrice = $this->calculateTotal((float) $room->getPricePerNight(), $checkIn, $checkOut);

        // 3. Instantiate and fill reservation
        $reservation = new Reservation();
        $reservation->setUser($user);
        $reservation->setRoom($room);
        $reservation->setCheckIn($checkIn);
        $reservation->setCheckOut($checkOut);
        $reservation->setGuests($guests);
        $reservation->setTotalPrice($totalPrice);
        $reservation->setStatus(Reservation::STATUS_PENDING);
        $reservation->setPaymentStatus(Reservation::PAYMENT_ON_SITE); // Always on site
        $reservation->setNotes($notes);

        $this->entityManager->persist($reservation);
        $this->entityManager->flush();

        return $reservation;
    }
}
