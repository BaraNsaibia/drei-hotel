<?php

namespace App\DataFixtures;

use App\Entity\Reservation;
use App\Entity\Room;
use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class AppFixtures extends Fixture
{
    public function __construct(
        private readonly UserPasswordHasherInterface $hasher
    ) {
    }

    public function load(ObjectManager $manager): void
    {
        // 1. Create Admin User
        $admin = new User();
        $admin->setEmail('admin@drei-hotel.com');
        $admin->setFirstName('Directeur');
        $admin->setLastName('Drei Hotel');
        $admin->setPhone('+33 123456789');
        $admin->setRoles(['ROLE_ADMIN']);
        $admin->setPassword($this->hasher->hashPassword($admin, 'Admin123!'));
        $manager->persist($admin);

        // 2. Create Demo Customers
        $user1 = new User();
        $user1->setEmail('client@drei-hotel.com');
        $user1->setFirstName('Karim');
        $user1->setLastName('Ben Salah');
        $user1->setPhone('+216 98 123 456');
        $user1->setRoles(['ROLE_USER']);
        $user1->setPassword($this->hasher->hashPassword($user1, 'Client123!'));
        $manager->persist($user1);

        $user2 = new User();
        $user2->setEmail('sarah@drei-hotel.com');
        $user2->setFirstName('Sarah');
        $user2->setLastName('Mansour');
        $user2->setPhone('+216 55 234 567');
        $user2->setRoles(['ROLE_USER']);
        $user2->setPassword($this->hasher->hashPassword($user2, 'Sarah123!'));
        $manager->persist($user2);

        $user3 = new User();
        $user3->setEmail('mehdi@drei-hotel.com');
        $user3->setFirstName('Mehdi');
        $user3->setLastName('Trabelsi');
        $user3->setPhone('+216 22 345 678');
        $user3->setRoles(['ROLE_USER']);
        $user3->setPassword($this->hasher->hashPassword($user3, 'Mehdi123!'));
        $manager->persist($user3);

        // 3. Create Rooms
        $roomStandard = new Room();
        $roomStandard->setName('Chambre Standard');
        $roomStandard->setType(Room::TYPE_STANDARD);
        $roomStandard->setDescription('Idéale pour les séjours professionnels ou les escapades en duo. Notre chambre standard offre un confort chaleureux, une literie de haute qualité et tous les équipements indispensables pour un repos parfait.');
        $roomStandard->setPricePerNight(120.00);
        $roomStandard->setCapacity(2);
        $roomStandard->setSurface(24);
        $roomStandard->setBedType('1 grand lit double Queen Size');
        $roomStandard->setImage('room-standard.jpg');
        $roomStandard->setStatus(Room::STATUS_AVAILABLE);
        $roomStandard->setAmenities([
            'Wi-Fi gratuit',
            'Climatisation individuelle',
            'Télévision écran plat HD',
            'Salle de bain privative avec douche à l\'italienne',
            'Sèche-cheveux',
            'Bureau de travail'
        ]);
        $manager->persist($roomStandard);

        $roomDeluxe = new Room();
        $roomDeluxe->setName('Chambre Deluxe');
        $roomDeluxe->setType(Room::TYPE_DELUXE);
        $roomDeluxe->setDescription('Un havre de paix élégant et spacieux doté d\'un balcon privé offrant une vue dégagée. Décorée dans les tons chauds et apaisants de l\'hôtel, elle dispose d\'un coin salon cosy et d\'attentions exclusives.');
        $roomDeluxe->setPricePerNight(180.00);
        $roomDeluxe->setCapacity(2);
        $roomDeluxe->setSurface(36);
        $roomDeluxe->setBedType('1 très grand lit King Size');
        $roomDeluxe->setImage('room-deluxe.jpg');
        $roomDeluxe->setStatus(Room::STATUS_AVAILABLE);
        $roomDeluxe->setAmenities([
            'Wi-Fi très haut débit',
            'Balcon privatif avec vue',
            'Climatisation silencieuse',
            'Mini-bar garni',
            'Machine à café Nespresso',
            'Peignoirs & chaussons',
            'Coffre-fort électronique'
        ]);
        $manager->persist($roomDeluxe);

        $suiteDrei = new Room();
        $suiteDrei->setName('Suite Drei');
        $suiteDrei->setType(Room::TYPE_SUITE);
        $suiteDrei->setDescription('Le fleuron de notre établissement. La Suite Drei allie raffinement, espace généreux et finitions d\'exception. Comprenant une chambre parentale avec lit King Size, un salon indépendant et une salle de bain avec baignoire balnéo.');
        $suiteDrei->setPricePerNight(320.00);
        $suiteDrei->setCapacity(4);
        $suiteDrei->setSurface(62);
        $suiteDrei->setBedType('1 lit King Size + 1 Canapé-lit grand confort');
        $suiteDrei->setImage('room-suite.jpg');
        $suiteDrei->setStatus(Room::STATUS_AVAILABLE);
        $suiteDrei->setAmenities([
            'Vue panoramique exceptionnelle',
            'Baignoire balnéothérapie & douche pluie',
            'Salon indépendant avec canapé design',
            'Service d\'étage VIP 24h/24',
            'Machine Nespresso & sélection de thés bio',
            'Deux Smart TV 4K 55"',
            'Accès prioritaire aux services de l\'hôtel'
        ]);
        $manager->persist($suiteDrei);

        $roomFamily = new Room();
        $roomFamily->setName('Chambre Familiale');
        $roomFamily->setType(Room::TYPE_FAMILY);
        $roomFamily->setDescription('Conçue spécialement pour les familles et groupes d\'amis désirant voyager ensemble sans compromis sur l\'espace et l\'intimité. Agencement optimal avec deux espaces de couchage distincts.');
        $roomFamily->setPricePerNight(240.00);
        $roomFamily->setCapacity(4);
        $roomFamily->setSurface(48);
        $roomFamily->setBedType('1 lit double + 2 lits simples confortables');
        $roomFamily->setImage('room-family.jpg');
        $roomFamily->setStatus(Room::STATUS_AVAILABLE);
        $roomFamily->setAmenities([
            'Wi-Fi gratuit multi-appareils',
            'Deux espaces couchage séparés',
            'Grande salle de bain familiale',
            'Mini-réfrigérateur',
            'Bouilloire électrique & boissons chaudes',
            'Climatisation réversible',
            'Chaînes TV enfants & streaming'
        ]);
        $manager->persist($roomFamily);

        // 4. Create Sample Reservations for demonstration
        // Reservation 1: Confirmed & Paid
        $res1 = new Reservation();
        $res1->setReference('DR-000101');
        $res1->setUser($user1);
        $res1->setRoom($roomDeluxe);
        $res1->setCheckIn(new \DateTime('+3 days'));
        $res1->setCheckOut(new \DateTime('+6 days'));
        $res1->setGuests(2);
        $res1->setTotalPrice(540.00); // 3 nights * 180 €
        $res1->setStatus(Reservation::STATUS_CONFIRMED);
        $res1->setPaymentStatus(Reservation::PAYMENT_PAID);
        $res1->setNotes('Arrivée prévue vers 18h.');
        $manager->persist($res1);

        // Reservation 2: Pending & Payment on site
        $res2 = new Reservation();
        $res2->setReference('DR-000102');
        $res2->setUser($user2);
        $res2->setRoom($suiteDrei);
        $res2->setCheckIn(new \DateTime('+8 days'));
        $res2->setCheckOut(new \DateTime('+10 days'));
        $res2->setGuests(3);
        $res2->setTotalPrice(640.00); // 2 nights * 320 €
        $res2->setStatus(Reservation::STATUS_PENDING);
        $res2->setPaymentStatus(Reservation::PAYMENT_ON_SITE);
        $res2->setNotes('Célébration d\'anniversaire de mariage.');
        $manager->persist($res2);

        // Reservation 3: Completed & Paid
        $res3 = new Reservation();
        $res3->setReference('DR-000098');
        $res3->setUser($user3);
        $res3->setRoom($roomStandard);
        $res3->setCheckIn(new \DateTime('-5 days'));
        $res3->setCheckOut(new \DateTime('-2 days'));
        $res3->setGuests(1);
        $res3->setTotalPrice(360.00); // 3 nights * 120 €
        $res3->setStatus(Reservation::STATUS_COMPLETED);
        $res3->setPaymentStatus(Reservation::PAYMENT_PAID);
        $manager->persist($res3);

        $manager->flush();
    }
}
